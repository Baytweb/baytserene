# Bayt Serene Website

This is the official website for **Bayt Serene**, a peaceful homestay located in Mount Lavinia, Sri Lanka.

## Features
- 2-room homestay with living area and kitchen
- Booking by room or full property
- Homemade meals on request
- LGBTQ+ friendly and family-focused
- Close to beach, religious sites, shops, and restaurants

## How to Run Locally

1. Install dependencies:
```bash
npm install
```

2. Start the app:
```bash
npm start
```

---

## Built With

- React.js
- Tailwind CSS (for styling)

---

## License

© Bayt Serene. All rights reserved.
